var merchantapp_config ={
	'ApiUrl':"https://istancool.co.uk/merchantappv2/api",
    'AppTitle':"CUISINNE",
	'ApiKey' : 'db20f3e4-f9f5-4ee0-a6a1-06477efaace0',
	'debug': false
};
